public interface IGuests {

    IGuests addElt(String elt);

    boolean hasElt(String elt);

    int size();
}
