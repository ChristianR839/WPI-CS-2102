public class Examples {
}
