import java.util.LinkedList;

public class Mouse {

    Food food;
    Workout workout;
    LinkedList<Weight> weightList = new LinkedList<Weight>();
}
