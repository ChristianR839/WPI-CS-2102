public class Weight extends Mouse {

    double weight;
    String date;
}
