public class Food extends Mouse {

    String foodType;
    double gramsOfFood;
}
