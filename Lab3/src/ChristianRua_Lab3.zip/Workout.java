public class Workout extends Mouse {

    int workoutsPerDay;
    int length;
}
