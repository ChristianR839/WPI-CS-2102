
public interface IContestant {

}
