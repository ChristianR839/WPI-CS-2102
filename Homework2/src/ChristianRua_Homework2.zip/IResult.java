
public interface IResult {

	public boolean isValid();

	public IContestant getWinner();
}
